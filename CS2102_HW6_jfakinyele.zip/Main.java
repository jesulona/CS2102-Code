public class Main {
    public static void main(String[] args) {
        ElectionData ED1 = new ElectionData();
        VotingMachine VM1 = new VotingMachine(ED1);
        VM1.screen();
    }
}
