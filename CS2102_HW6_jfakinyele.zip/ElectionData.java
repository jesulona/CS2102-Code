import java.util.HashMap;
import java.util.LinkedList;

class ElectionData {

    private LinkedList<String> ballot = new LinkedList<String>();
    //uncucessful at implimenting IBallot

    ElectionData() {    }

    /**
     * Each HashMap uses the candidates name as the key and stores the number of
     * votes in that choice category
     */
    private HashMap<String, Integer> firstChoiceHash = new HashMap<String, Integer>(); // first choice votes for all candidates
    private HashMap<String, Integer> secondChoiceHash = new HashMap<String, Integer>(); // second choice votes for all candidates
    private HashMap<String, Integer> thirdChoiceHash = new HashMap<String, Integer>(); // third choice votes for all candidates


    /**
     * helper function for process vote
     * identifies valid votes
     *
     * @param firstChoice
     * @param secondChoice
     * @param thirdChoice
     * @return
     */
    public boolean validVote(String firstChoice, String secondChoice, String thirdChoice) {
        if (ballot.contains(firstChoice)
                && ballot.contains(secondChoice)
                && ballot.contains(thirdChoice)
                && !(firstChoice.equals(secondChoice))
                && !(secondChoice.equals(thirdChoice))
                && !(firstChoice.equals(thirdChoice))) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * processVote
     * takes three strings (for the first, second, and third choices, respectively) and returns void.
     * stores a single voter's choices in our data structure.
     *
     * @param firstChoice
     * @param secondChoice
     * @param thirdChoice
     * @throws UnknownCandidateException
     * @throws DuplicateVotesException
     */
    public void processVote(String firstChoice, String secondChoice, String thirdChoice) throws UnknownCandidateException, DuplicateVotesException {
        if (validVote(firstChoice, secondChoice, thirdChoice)) {
            firstChoiceHash.put(firstChoice, firstChoiceHash.get(firstChoice) + 1);
            secondChoiceHash.put(secondChoice, secondChoiceHash.get(secondChoice) + 1);
            thirdChoiceHash.put(thirdChoice, thirdChoiceHash.get(secondChoice) + 1);
        } else if (!(ballot.contains(firstChoice))) {

            throw new UnknownCandidateException(firstChoice);

        } else if (!(ballot.contains(secondChoice))) {

            throw new UnknownCandidateException(secondChoice);

        } else if (!(ballot.contains(thirdChoice))) {

            throw new UnknownCandidateException(thirdChoice);

        } else if (firstChoice.equals(secondChoice)) {

            throw new DuplicateVotesException(firstChoice);

        } else if (secondChoice.equals(thirdChoice)) {

            throw new DuplicateVotesException(secondChoice);

        } else {

            throw new DuplicateVotesException(thirdChoice);
        }
    }

    /**
     * addCandidate
     * takes one string (for the name of a candidate) and adds
     * the candidate to the ballot
     *
     * @param nameCan
     * @throws CandidateExistsException
     */
    public void addCandidate(String nameCan) throws CandidateExistsException {
        if (!(ballot.contains(nameCan))) {
            firstChoiceHash.put(nameCan, 0);
            secondChoiceHash.put(nameCan, 0);
            thirdChoiceHash.put(nameCan, 0);
            this.ballot.add(nameCan);
        } else {

            throw new CandidateExistsException(nameCan);

        }
    }


    public void printBallot() {
        System.out.println("The candidates are ");
        for (String s : ballot) {
            System.out.println(s);
        }
    }



    /**
     * totalFirtChoiceVotes
     * helper for findWinnerMostFirstVotes
     * returns the sum of all the first place votes
     * for all the candidates
     * @return sum
     */
    private double totalFirtChoiceVotes() {
        double sum = 0;
        for (String candidate : ballot) {
            sum = sum + firstChoiceHash.get(candidate);
        }
        return sum;
    }

    /**
     * findWinnerMostFirstVotes
     * winner is the candidate with more than 50% of first place votes.
     * If there is a tie for the most votes between two or more candidates, or if no
     * candidate receives more than 50% of the votes, return the string "Runoff required"
     *
     * @return candidate or error message
     */
    public String findWinnerMostFirstVotes() {
        double percentage;
        double totalVotes = totalFirtChoiceVotes();

        for (String candidate : ballot) {
            percentage = firstChoiceHash.get(candidate) / totalVotes;

            if (percentage > (0.5)) {
                return candidate;
            }
        }
        return "Runoff required";

    }

    /** findWinnerMostPoints
     *  winner is the candidate with the most points under the following formula:
     *  three points for each first-place vote they received,
     *  two points for each second-place vote they received,
     *  and one point for each third-place vote they received.
     *  If there is a tie between two or more candidates,
     *  return the name of any one of the winners (it doesn't matter which).
     * @return the winner
     */
    public String findWinnerMostPoints() {
        int mostPoints = 0;
        int points;
        String winner = ballot.getFirst();
        for(String candidate : ballot) {
            points = firstChoiceHash.get(candidate) * 3
                    + secondChoiceHash.get(candidate) * 2
                    + thirdChoiceHash.get(candidate);

            if(points > mostPoints) {
                mostPoints = points;
                winner = candidate;
            }
        }
        return winner;
    }

}

