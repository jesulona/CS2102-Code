public class CandidateExistsException extends Exception {

    private String nameCan;

    public CandidateExistsException(String nameCan) {
        this.nameCan = nameCan;
    }
}
