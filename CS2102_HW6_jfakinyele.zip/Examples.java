import org.junit.Test;

import static org.junit.Assert.*;

public class Examples {
    public Examples() {
    }

    public ElectionData Setup1() {

        ElectionData ED = new ElectionData();

        try {
            // put candidates on the ballot
            ED.addCandidate("gompei");
            ED.addCandidate("husky");
            ED.addCandidate("ziggy");
            ED.addCandidate("jackson");
            ED.addCandidate("carl");


            // cast votes
            ED.processVote("gompei", "husky", "ziggy");
            ED.processVote("gompei", "husky", "jackson");
            ED.processVote("husky", "carl", "ziggy");
            ED.processVote("ziggy", "husky", "jackson");
            ED.processVote("gompei", "husky", "ziggy");
            ED.processVote("gompei", "husky", "ziggy");


        } catch (Exception e) {
        }
        return (ED);
    }

    public ElectionData Setup2() {

        ElectionData ED = new ElectionData();

        try {
            // put candidates on the ballot
            ED.addCandidate("gompei");
            ED.addCandidate("husky");
            ED.addCandidate("ziggy");
            ED.addCandidate("jackson");
            ED.addCandidate("carl");


            // cast votes
            ED.processVote("gompei", "husky", "ziggy");
            ED.processVote("gompei", "husky", "jackson");
            ED.processVote("husky", "carl", "ziggy");
            ED.processVote("gompei", "husky", "jackson");
            ED.processVote("jackson", "husky", "ziggy");
            ED.processVote("carl", "husky", "ziggy");


        } catch (Exception e) {
        }
        return (ED);
    }

    @Test
    public void testMostFirstWinner() {
        assertEquals("gompei", Setup1().findWinnerMostFirstVotes());
    }

    @Test
    public void testMostPointsWinner() {
        assertEquals("husky", Setup2().findWinnerMostPoints());
    }

    @Test
    public void testMostFirstWinner2 () {
        assertEquals ("Runoff required", Setup2().findWinnerMostFirstVotes());
    }

    @Test(expected = CandidateExistsException.class)
    public void testMostFirstWinnerExc() throws CandidateExistsException {
        Setup1().addCandidate("gompei");
    }

    @Test(expected = UnknownCandidateException.class)
    public void testFirstCandUnknown() throws UnknownCandidateException, DuplicateVotesException {

        Setup1().processVote("luther", "ziggy", "gompei");
    }

    @Test(expected = UnknownCandidateException.class)
    public void testSecondCandUnknown() throws UnknownCandidateException, DuplicateVotesException {

        Setup1().processVote("husky", "homer", "gompei");
    }

    @Test(expected = UnknownCandidateException.class)
    public void testThirdCandUnknown() throws UnknownCandidateException, DuplicateVotesException {

        Setup1().processVote("husky", "gompei", "lisa");
    }


    @Test(expected = DuplicateVotesException.class)
    public void testDuplicateCand() throws DuplicateVotesException, UnknownCandidateException {
        Setup1().processVote("gompei", "gompei", "husky");
    }

    @Test(expected = UnknownCandidateException.class)
    public void testUnknownBeforDuplicate() throws UnknownCandidateException, DuplicateVotesException {

        Setup1().processVote("maxy", "maxy", "gompei");
    }
}
