import java.util.LinkedList;

public interface IBallot {
    public boolean contains(String string);
    public void add(String string);
    public void printcandidates();
    public  String getFirst();
    public LinkedList<String> namesOfCand();
}
