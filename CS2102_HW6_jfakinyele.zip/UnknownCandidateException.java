public class UnknownCandidateException extends Exception {

    private String unknownName;

    UnknownCandidateException(String name){
        this.unknownName = name;
    }

    public String getUnknownName() {
        return this.unknownName;
    }
}
