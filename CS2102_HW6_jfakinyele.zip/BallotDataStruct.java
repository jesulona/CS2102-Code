import java.util.HashMap;
import java.util.LinkedList;

public class BallotDataStruct implements IBallot{

    private LinkedList<String> ballot;

    public BallotDataStruct() {this.ballot = new LinkedList<String>();}

    @Override
    public void add(String string) {
        this.ballot.add(string);
    }

    @Override
    public boolean contains(String string){
        if (this.contains(string)){
            return true;
        } return false;
    }

    public void printcandidates(){
        for (String s : ballot) {
            System.out.println(s);
        }
    }

    @Override
    public String getFirst() {
       return this.ballot.getFirst();
    }

    public LinkedList<String> namesOfCand(){
        return ballot;
    }


}
