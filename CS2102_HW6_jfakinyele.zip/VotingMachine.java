import java.util.Scanner;

public class VotingMachine {
    private Scanner keyboard = new Scanner(System.in);
    private ElectionData election = new ElectionData();

    VotingMachine(ElectionData election) {
        this.election = election;
    }

    public void addWriteIn(String newCandName) {
        try {
            election.addCandidate(newCandName);
        } catch (CandidateExistsException e) {
            System.out.println("The candidate already exists.");
        }
        System.out.println("The candidate was successfully added.");
    }

    public void screen() {
        System.out.println("Who do you want to vote for as your 1st choice?");
        String firstChoice = keyboard.next();
        System.out.println("Who do you want to vote for as your 2nd choice?");
        String secondChoice = keyboard.next();
        System.out.println("Who do you want to vote for as your 3rd choice?");
        String thirdChoice = keyboard.next();

        try {
            election.processVote(firstChoice, secondChoice, thirdChoice);
        } catch (UnknownCandidateException e) {
            System.out.println("Would like to add " + e.getUnknownName() + "'s name to the ballot?");
            String addQ = keyboard.next();
            String addQi = addQ.toLowerCase();
            if (addQi.equals("y")) {
                addWriteIn(e.getUnknownName());
            }
            this.screen();
            return;
        } catch (DuplicateVotesException e) {
            System.out.println("You can't vote for the same person more than once.");
            this.screen();
            return;
        }
        System.out.println("You voted for " + firstChoice + ", " + secondChoice + " and " + thirdChoice);
    }

}
