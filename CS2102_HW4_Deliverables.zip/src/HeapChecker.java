import java.util.Collections;
import java.util.LinkedList;

public class HeapChecker {

    /**
     * addEltTester takes a heap, an integer, and a
     * binary tree and returns true if the binary tree
     * is a valid result of adding the given
     * integer to the first Heap
     *
     * @param hOrig  the heap
     * @param elt    the element being added to the heap
     * @param hAdded the binary search tree after the addition
     * @return boolean
     */
    boolean addEltTester(IHeap hOrig, int elt, IBinTree hAdded) {
        if (hOrig.size() + 1 != hAdded.size()) {
            return false;
        }
        LinkedList<Integer> hOrigList = new LinkedList<>();
        LinkedList<Integer> hAddedList = new LinkedList<>();
        if (hAdded.isHeap()) {
            hOrigList = hOrig.heapToList();
            hOrigList.add(elt);
            hAddedList = hAdded.heapToList();
            Collections.sort(hOrigList);
            Collections.sort(hAddedList);
            for (int i = 0; i < hOrigList.size(); i++) {
                if (hOrigList.get(i) != hAddedList.get(i)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * remMinEltTester takes a heap and a binary tree and
     * checks that the binary tree is the result
     * of removing the smallest element of the heap.
     *
     * @param hOrig
     * @param hRemoved
     * @return
     */
    boolean remMinEltTester(IHeap hOrig, IBinTree hRemoved) {
        if (hOrig.size() - 1 != hRemoved.size()) {
            return false;
        }
        LinkedList<Integer> hOrigList = new LinkedList<>();
        LinkedList<Integer> hRemovedList = new LinkedList<>();
        if (hRemoved.isHeap()) {
            hOrigList = hOrig.heapToList();
            hRemovedList = hRemoved.heapToList();
            Collections.sort(hOrigList);
            Collections.sort(hRemovedList);
            hOrigList.removeFirst();
            for (int i = 0; i < hOrigList.size(); i++) {
                if (hOrigList.get(i) != hRemovedList.get(i)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
}

