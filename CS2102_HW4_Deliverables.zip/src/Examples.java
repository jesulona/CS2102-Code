import org.junit.Test;

import java.util.LinkedList;

import static org.junit.Assert.*;

public class Examples {

    HeapChecker H1 = new HeapChecker();
    IHeap badHeap = new DataHeap(5, new DataHeap(3, new MtHeap(), new MtHeap()), new MtHeap());
    IHeap heap1 = new DataHeap(2,
            new DataHeap(2, new DataHeap(5, new MtHeap(), new MtHeap()), new MtHeap()),
            new DataHeap(8, new DataHeap(11, new MtHeap(), new MtHeap()), new DataHeap(11, new MtHeap(), new MtHeap())));
    IHeap heap2 = new DataHeap(2,
            new DataHeap(8, new DataHeap(11, new MtHeap(), new MtHeap()), new DataHeap(11, new MtHeap(), new MtHeap())),
            new DataHeap(2, new DataHeap(5, new MtHeap(), new MtHeap()), new MtHeap()));
    IHeap heap3 = new DataHeap(2,
            new DataHeap(2, new DataHeap(5, new MtHeap(), new MtHeap()), new MtHeap()),
            new DataHeap(8, new DataHeap(8, new MtHeap(), new MtHeap()), new DataHeap(11, new MtHeap(), new MtHeap())));
    IHeap heap4 = new DataHeap(2,
            new DataHeap(2, new DataHeap(5, new MtHeap(), new MtHeap()), new MtHeap()),
            new DataHeap(8, new DataHeap(11, new MtHeap(), new MtHeap()), new DataHeap(11, new MtHeap(), new MtHeap())));
    IHeap heap5 = new DataHeap(2,
            new DataHeap(2, new DataHeap(5, new MtHeap(), new MtHeap()), new MtHeap()),
            new DataHeap(8, new DataHeap(11, new MtHeap(), new MtHeap()), new DataHeap(11, new DataHeap(17, new MtHeap(), new MtHeap()), new DataHeap(20, new MtHeap(), new MtHeap()))));

    @Test
    public void testIsHeap() {
        assertTrue(heap1.isHeap());
    }

    @Test
    public void testIsHeapWithBadHeap() {
        assertFalse(badHeap.isHeap());
    }

    @Test
    public void testAddEltTester() {

        assertTrue(H1.addEltTester(heap1, 2, heap1.addElt(2)));

    }

    @Test
    public void testAddEltTester2() {

        assertTrue(H1.addEltTester(heap1, 3, heap2.addElt(3)));

    }

    @Test
    public void testAddEltTesterNonHeap() {
        assertFalse(H1.addEltTester(badHeap, 8, badHeap.addElt(8)));
    }

    @Test
    public void testAddEltTesterWrongOutput() {

        assertFalse(H1.addEltTester(heap1, 3, heap3.addElt(3)));

    }

    @Test
    public void testAddEltTesterWrongOccurences() {
        assertFalse(H1.addEltTester(heap1, 5, heap4));

    }

    @Test
    public void testAddEltTesterWrongOccurences2() {
        heap4.addElt(5);
        heap4.addElt(5);
        assertFalse(H1.addEltTester(heap1, 5, heap4));
    }

    @Test
    public void testAddEltTesterWrongSize() {
        assertFalse(H1.addEltTester(heap1, 3, heap5.addElt(3)));
    }

    //remMinEltTester
    @Test
    public void testRemMinEltTester() {

        assertTrue(H1.remMinEltTester(heap1, heap1.remMinElt()));

    }

    @Test
    public void testRemMinEltTester2() {

        assertTrue(H1.remMinEltTester(heap1, heap2.remMinElt()));

    }

    @Test
    public void testRemMinEltTesterNonHeap() {
        assertFalse(H1.remMinEltTester(badHeap, badHeap.remMinElt()));
    }

    @Test
    public void testRemMinEltTesterWrongOutput() {

        assertFalse(H1.remMinEltTester(heap1, heap3.remMinElt()));

    }

    @Test
    public void testRemMinEltTesterWrongOccurences() {
        assertFalse(H1.remMinEltTester(heap1, heap4));

    }

    @Test
    public void testRemMinEltTesterWrongSize() {
        assertFalse(H1.remMinEltTester(heap1, heap5.remMinElt()));
    }
}

