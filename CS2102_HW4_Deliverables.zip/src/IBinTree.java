import java.lang.Math;
import java.util.LinkedList;

interface IBinTree {
 // determines whether element is in the tree
 boolean hasElt(int e);
 // returns number of nodes in the tree; counts duplicate elements as separate items
 int size();
 // returns depth of longest branch in the tree
 int height();
 //Determines if a BinTree is a heap
 boolean isHeap();
 //Determine if the root of this heap is bigger than the given element
 boolean isBigger(int data);
 //Converts a heap into a linkedList of data
 public LinkedList<Integer> heapToList();
}



