import java.util.GregorianCalendar;
import java.util.LinkedList;

public class DailyWeatherReport {
    private GregorianCalendar date;
    private LinkedList<Double> tempReadings;
    private LinkedList<Double> rainfallReadings;



    public DailyWeatherReport(GregorianCalendar date, LinkedList<Double> temp, LinkedList<Double> rainfallReadings) {
        this.date = date;
        this.tempReadings = tempReadings;
        this.rainfallReadings = rainfallReadings;

    }


    /**
     * getter for the average temperature on the date
     * @return average temperature
     */
    public double getAvgTemp(){
        double tempSum = 0;
        int tempCount = 0;
        for(Double reading: tempReadings){
            tempSum += reading;
        }
        return tempSum/tempReadings.size();
    }

    /**
     * getter for month of date
     * @return month
     */
    public int getMonth(){
        return this.date.get(GregorianCalendar.MONTH);
    }

    /**
     * getter for the year of the date
     * @return year
     */
    public int getYear(){
        return this.date.get(GregorianCalendar.YEAR);
    }

    /**
     * getter for the total rainfall of the date
     * @return total rainfall
     */
    public double getTotalRainfall(){
        double rainSum = 0;
        for(double rain: rainfallReadings){
            rainSum +=rain;
        }
        return rainSum;
    }

}

