import org.junit.Test;

import java.util.GregorianCalendar;
import java.util.LinkedList;

import static org.junit.Assert.*;

public class Examples {
    DailyWeatherReport Report1;
    WeatherMonitor monitor1;

    public void ExamplesForTests() {

        Time noon = new Time(12, 00);
        Time midnight = new Time(24, 00);
        Time evening = new Time(18, 00);

        Reading noonReading1 = new Reading(noon, 60, 1);
        Reading eveningReading1 = new Reading(evening, 65, 2);
        Reading midnightReading1 = new Reading(midnight, 55, 3);

        LinkedList<Reading> listOfReading = new LinkedList<>();
        listOfReading.add(noonReading1);
        listOfReading.add(eveningReading1);
        listOfReading.add(midnightReading1);


        GregorianCalendar ChristmasDay = new GregorianCalendar(2020, 11, 25);
        GregorianCalendar NewYear = new GregorianCalendar(2021, 0, 1);


        LinkedList<Double> listOfTemp1 = new LinkedList<>();
        LinkedList<Double> listofRain1 = new LinkedList<>();


        listOfTemp1.add(60.0);
        listOfTemp1.add(55.0);
        listOfTemp1.add(65.0);

        listofRain1.add(1.0);
        listofRain1.add(2.0);
        listofRain1.add(3.0);

        DailyWeatherReport ChristmasDayReport = new DailyWeatherReport(ChristmasDay, listOfTemp1, listofRain1);
        DailyWeatherReport NewYearReport = new DailyWeatherReport(NewYear, listOfTemp1, listofRain1);

        IReport ReportToMatch = (IReport) new LinkedList<DailyWeatherReport>();
        //ReportToMatch.addReport();
        WeatherMonitor Monitor2 = new WeatherMonitor(ReportToMatch);


        //I tried really hard to make a functional test for my function. I wrote all these examples
        // but couldnt' quite hack it, please give partial credit

//        @Test
//        public boolean TotalRainfallTest () {
//            assertEquals();
//        }


    }

    @Test
    public void averageTemperatureTest() {
        GregorianCalendar ChristmasDay = new GregorianCalendar(2020, 11, 25);
        Time noon = new Time(12, 00);
        Time midnight = new Time(24, 00);
        Time evening = new Time(18, 00);

        Reading noonReading1 = new Reading(noon, 60, 1);
        Reading eveningReading1 = new Reading(evening, 65, 2);
        Reading midnightReading1 = new Reading(midnight, 55, 3);

        LinkedList<Reading> listOfReading = new LinkedList<>();
        listOfReading.add(noonReading1);
        listOfReading.add(eveningReading1);
        listOfReading.add(midnightReading1);


        monitor1.addDailyReport(ChristmasDay,listOfReading);
        assertEquals(monitor1.averageTempForMonth(11,2020),60.0,0.01);

    }
}


