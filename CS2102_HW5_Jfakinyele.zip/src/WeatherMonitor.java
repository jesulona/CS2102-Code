import java.util.GregorianCalendar;
import java.util.LinkedList;

public class WeatherMonitor {

    private IReport dailyReports;

    public WeatherMonitor(IReport dailyReports) {
        this.dailyReports = dailyReports;
    }

    /**
     * takes a month (0 for January, 1 for February, etc) and a year
     * and produces the average temperature over all days that month.
     *
     * @param month- month we are interested in
     * @param year   - year we are interested in
     * @return the average temperature for that month
     */
    double averageTempForMonth(int month, int year) {
        return dailyReports.getAvgTemp(month, year);
    }


    /**
     * takes a month and a year and produces the total
     * rainfall over all days that month.
     *
     * @param month- month we are interested in
     * @param year   - year we are interested in
     * @return the total rainfall for that month
     */
    double totalRainfallForMonth(int month, int year) {
        return dailyReports.getTotalRainfall(month, year);
    }

    /**
     * consumes a date and a list of readings (nominally for that date)
     * and stores a daily report for the given date.
     *
     * @param date
     * @param listOfreadings
     * @return
     */
    void addDailyReport(GregorianCalendar date, LinkedList<Reading> listOfreadings) {
        dailyReports.addReport(date, listOfreadings);
    }
}
