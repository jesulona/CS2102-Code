import java.util.GregorianCalendar;
import java.util.LinkedList;

public class ReportList implements IReport {

    private LinkedList<DailyWeatherReport> dailyReports;

    public ReportList(LinkedList<DailyWeatherReport> dailyReports) {
        this.dailyReports = dailyReports;
    }

    /**
     * caclulates average temperature for given month in year
     * @param month month
     * @param year year
     * @return average temp
     */
    @Override
    public double getAvgTemp(int month, int year) {
        double avgTemp = 0;
        for(DailyWeatherReport report: this.dailyReports){
            if(report.getMonth()==month && report.getYear()==year){
                avgTemp = report.getAvgTemp();
            }
        }
        return avgTemp;
    }


    /**
     * calculates total rainfall within given month
     * in that year
     * @param month month
     * @param year year
     * @return total rainfall
     */
    @Override
    public double getTotalRainfall(int month, int year) {
        double totalRain = 0;
        for(DailyWeatherReport report: this.dailyReports){
            if(report.getMonth()==month && report.getYear()==year){
                totalRain = report.getTotalRainfall();
            }
        }
        return totalRain;
    }

    //Helpers for addReport

    public LinkedList<Double> getTempList(LinkedList<Reading> readings) {
        LinkedList<Double> listOftemp = new LinkedList<>();
        for (Reading reading : readings){
            listOftemp.add(reading.getTemperature());
        }
        return listOftemp;
    }

    public LinkedList<Double> getRainList(LinkedList<Reading> readings) {
        LinkedList<Double> listOfRain = new LinkedList<>();
        for (Reading reading : readings){
            listOfRain.add(reading.getRainfall());
        }
        return listOfRain;
    }

    /**
     * adds a report to a list of reports
     *
     */
    @Override
    public void addReport(GregorianCalendar date, LinkedList<Reading> listOfreadings) {
        DailyWeatherReport newReport = new DailyWeatherReport(date, getTempList(listOfreadings), getRainList(listOfreadings));
        dailyReports.add(newReport);
    }

}
