public class Reading {
    private Time timeOfReading;
    private Double temp;
    private Double rainfall;

    public Reading(Time timeOfReading, double temp, double rainfall){
        this.timeOfReading = timeOfReading;
        this.temp = temp;
        this.rainfall = rainfall;
    }


    /**
     * getter for reading temperature
     * @return temperature
     */
    public double getTemperature() {
        return temp;
    }

    /**
     * getter for reading rainfall
     * @return rainfall
     */
    public double getRainfall() {
        return rainfall;
    }


}
