import java.util.GregorianCalendar;
import java.util.LinkedList;

public interface IReport {
    /**
     * getter for average temperature for the specified month and year
     * @param month month
     * @param year year
     * @return average temperature
     */
    double getAvgTemp(int month, int year);

    /**
     * getter for total rainfall in the specified month and year
     * @param month month
     * @param year year
     * @return total rainfall
     */
    double getTotalRainfall(int month, int year);

    /**
     * adds a daily report to the collection of reports
     * @param report dailyWeatherReport for a specific date
     */
    void addReport(GregorianCalendar date, LinkedList<Reading> listOfreadings);
}
