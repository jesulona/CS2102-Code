public class Time {
    private int hours;
    private int mins;

    Time(int hours, int mins){
        this.hours = hours;
        this.mins = mins;
    }

    /**
     * getter for the hour of time
     * @return hour
     */
    public int getHour() {
        return hours;
    }

    /**
     * getter for the minute of time
     * @return minute
     */
    public int getMinute() {
        return mins;
    }
}
