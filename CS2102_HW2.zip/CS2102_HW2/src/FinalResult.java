public class FinalResult {
    ShootingResult resultOfShooting;
    SkiingResult resultOfSkiing;

    public FinalResult(ShootingResult resultOfShooting, SkiingResult resultOfSkiing) {
        this.resultOfShooting = resultOfShooting;
        this.resultOfSkiing = resultOfSkiing;
    }

    // mostAthletes() is a helper function that is the
    // default final score for an athlete in the event
    // they do not place.
    public double mostAthletes() {
        return resultOfSkiing.pointsEarned() + resultOfSkiing.getPenalties() + resultOfShooting.getPenalties();
    }

    // using it's helper function, finalScore()
    // calculate the final score of the athlete
    // and then modifies if necessary
    public double finalScore() {

        if (resultOfSkiing.finalPosition == 1) {
            return mostAthletes() - 10;
        }
        if (resultOfSkiing.finalPosition == 2) {
            return mostAthletes() - 7;
        }
        if (resultOfSkiing.finalPosition == 3) {
            return mostAthletes() - 3;
        }
        if (resultOfSkiing.finalPosition == 4) {
            return mostAthletes() - 1;
        } else return mostAthletes();

    }

}
