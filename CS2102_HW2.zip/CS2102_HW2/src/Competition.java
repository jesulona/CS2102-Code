import java.util.LinkedList;

public class Competition {
    int numShootingRounds;
    LinkedList<Athlete> listOfAthletes;

    public LinkedList<String> shootingDNF() {
        LinkedList<String> namesDNF = new LinkedList<>();
        for (Athlete lete : this.listOfAthletes) {
            if (lete.athleteResult.resultOfShooting.listOfShootingRound.size() < numShootingRounds) {
                namesDNF.add(lete.name);
            }
        }
        return namesDNF;
    }

    public Athlete findAthlete(String nameofAthlete) {
        Athlete returnAthlete = null;
        for (Athlete lete : this.listOfAthletes) {
            if (lete.name.equals(nameofAthlete)) {
                returnAthlete = lete;
            }
        }
        return returnAthlete;
    }

    public Double finalScoreForAthlete(String nameOfAthlete) {
        return findAthlete(nameOfAthlete).athleteResult.finalScore();
    }

    public Athlete findAthlete(LinkedList<Athlete> listOfA, String athleteName) {
        Athlete rAthlete = null;
        for (Athlete allAthletes : listOfA) {
            if (athleteName.equals(allAthletes.name)) {
                rAthlete = allAthletes;
            }
        }
        return rAthlete;
    }

    public Boolean anyImprovement(Competition otherCompetition) {

        Boolean returnBool = false;

        for (Athlete everyAthlete : this.listOfAthletes) {
            if ((finalScoreForAthlete(everyAthlete.name) > finalScoreForAthlete(findAthlete(otherCompetition.listOfAthletes, everyAthlete.name).name))) {
                returnBool = true;
            }
        } return returnBool;
    }

    //Number 13
    /** I am quite satisfied with finalScoreAthlete because I wrote a good helper function
     * to simplify the task; however, I feel like the helper might not have been needed,
     * as there is probably some default Java function that does what I wanted done.
     *
     * I do not like my implementation of any Improvement as I believe it is quote convoluted.
     * I could probably write the function neater and in a more logical way but.
     * I just wanted to finish the homework
     */
}
