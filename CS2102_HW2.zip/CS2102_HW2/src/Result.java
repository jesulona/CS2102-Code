import java.util.LinkedList;

public abstract class Result {
    int finalPosition;
    LinkedList<Double> laps;
    double lap1Time;
    double lap2Time;
    double lap3Time;
    double lap4Time;
    int penaltiesEarned;

    public Result(int finalPosition, double lap1Time, double lap2Time,
                        double lap3Time, double lap4Time, int penaltiesEarned) {
        this.finalPosition = finalPosition;
        this.lap1Time = lap1Time;
        this.lap2Time = lap2Time;
        this.lap3Time = lap3Time;
        this.lap4Time = lap4Time;
        this.penaltiesEarned = penaltiesEarned;
        this.laps = new LinkedList<>();
        laps.add(lap1Time);
        laps.add(lap2Time);
        laps.add(lap3Time);
        laps.add(lap4Time);
    }
    // pointsEarned() calculates the points earned by
    // summing the lap times
    public double pointsEarned() {
        double totalPoints = 0;
        for (Double time : this.laps) {
            totalPoints += time;
        }
        return totalPoints;
    }

    // getPenalties() calculates the penalties by
    // multiplying the penalties earned by 5
    public double getPenalties() {
        return (5 * penaltiesEarned);
    }
}

