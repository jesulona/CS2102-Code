public class ShootingRound {

    int roundHits;
    boolean standing;

    public ShootingRound(int roundHits, boolean standing) {

        this.roundHits = roundHits;
        this.standing = standing;
    }
}
