public class Athlete {

    FinalResult athleteResult;
    String name;

    public Athlete(FinalResult athleteResult, String name) {

        this.athleteResult = athleteResult;
        this.name = name;

    }

    // betterSkiier determines if the athlete is better than
    // the input athlete at skiing
    public boolean betterSkiier(Athlete otherAthlete){
        return this.athleteResult.resultOfSkiing.pointsEarned() < otherAthlete.athleteResult.resultOfSkiing.pointsEarned();
    }

    // betterShooter determines if the athlete is a better
    // shooter than the input athlete
    public boolean betterShooter(Athlete otherAthlete){
        return this.athleteResult.resultOfShooting.pointsEarned() > otherAthlete.athleteResult.resultOfShooting.pointsEarned();
    }

    // hasBeaten determines if the ahtlete has a better
    // result in a category than the input athlete
    public boolean hasBeaten(Athlete otherAthlete){
        return (this.betterSkiier(otherAthlete) || (this.betterShooter(otherAthlete)));
    }
}
