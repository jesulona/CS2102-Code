
public class SkiingResult extends Result implements IEvent {

    public SkiingResult(int finalPosition, double lap1Time, double lap2Time,
                        double lap3Time, double lap4Time, int penaltiesEarned) {
        super(finalPosition, lap1Time, lap2Time, lap3Time, lap4Time, penaltiesEarned);
    }

}
