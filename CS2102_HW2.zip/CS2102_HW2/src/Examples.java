import org.junit.Test;

import java.util.LinkedList;

import static org.junit.Assert.*;

public class Examples {

    // Athlete 1 Stuff
//    ShootingRound athlete1Round1 = new ShootingRound(1);
//    ShootingRound athlete1Round2 = new ShootingRound(5);
//    ShootingRound athlete1Round3 = new ShootingRound(5);
//    ShootingRound athlete1Round4 = new ShootingRound(5);


    SkiingResult athlete1ResultOfSkiing = new SkiingResult(1, 2.30, 2.50, 3.02, 3.30, 3);

    LinkedList<ShootingRound> a1ListOfShooting = new LinkedList<ShootingRound>();

    LinkedList<ShootingRound> athlete2ListOfShooting = new LinkedList<ShootingRound>();

    ShootingResult athlete1ResultOfShooting = new ShootingResult(a1ListOfShooting);


    FinalResult athlete1Result = new FinalResult(athlete1ResultOfShooting, athlete1ResultOfSkiing);

    Athlete athlete1 = new Athlete(athlete1Result, "Athlete1");

    // Athlete 2 Stuff
//    ShootingRound athlete2Round1 = new ShootingRound(5);
//    ShootingRound athlete2Round2 = new ShootingRound(5);
//    ShootingRound athlete2Round3 = new ShootingRound(5);
//    ShootingRound athlete2Round4 = new ShootingRound(5);

    SkiingResult athlete2ResultOfSkiing = new SkiingResult(2, 2.30, 5.00, 3.02, 3.30, 3);

    LinkedList<ShootingRound> a2ListOfShooting = new LinkedList<ShootingRound>();

    ShootingResult athlete2ResultOfShooting = new ShootingResult(a2ListOfShooting);

    FinalResult athlete2Result = new FinalResult(athlete2ResultOfShooting, athlete2ResultOfSkiing);

    Athlete athlete2 = new Athlete(athlete2Result, "Athlete2");

    // Athlete 3 Stuff
//    ShootingRound athlete3Round1 = new ShootingRound(1);
//    ShootingRound athlete3Round2 = new ShootingRound(3);
//    ShootingRound athlete3Round3 = new ShootingRound(2);
//    ShootingRound athlete3Round4 = new ShootingRound(5);

    SkiingResult athlete3ResultOfSkiing = new SkiingResult(9, 5.00, 5.00, 6.20, 4.90, 5);

    LinkedList<ShootingRound> a3ListOfShooting = new LinkedList<>();

    ShootingResult athlete3ResultOfShooting = new ShootingResult(a3ListOfShooting);

    FinalResult athlete3Result = new FinalResult(athlete3ResultOfShooting, athlete3ResultOfSkiing);

    Athlete athlete3 = new Athlete(athlete3Result, "Athlete3");


    //All Tests

    @Test
    public void pointsEarnedTestSkiing() {
        assertEquals(athlete1.athleteResult.resultOfSkiing.pointsEarned(), 11.12, 0.01);
    }

    @Test
    public void getPenaltiesTest() {
        assertEquals(athlete1.athleteResult.resultOfSkiing.getPenalties(), (athlete1.athleteResult.resultOfSkiing.penaltiesEarned * 5), 0.01);
    }

    @Test
    public void pointsEarnedTestShooting() {
        assertEquals(athlete1.athleteResult.resultOfShooting.pointsEarned(), 16, 0.01);
    }

    @Test
    public void getPenaltiesTest1() {
        assertEquals(athlete2.athleteResult.resultOfShooting.getPenalties(), 0, 0.01);
    }

    @Test
    public void getPenaltiesTest2() {
        assertEquals(athlete1.athleteResult.resultOfShooting.getPenalties(), 240, 0.01);
    }

    @Test
    public void mostAthletesHelperTest1() {
        assertEquals(athlete3.athleteResult.finalScore(), athlete3.athleteResult.mostAthletes(), 0.01);
    }

    @Test
    public void mostAthletesHelperTest2() {
        assertEquals(athlete3.athleteResult.finalScore(), athlete3.athleteResult.mostAthletes(), 0.01);
    }

    @Test
    public void finalScoreTest1() {
        assertEquals(athlete1.athleteResult.finalScore(), athlete1.athleteResult.mostAthletes() - 10, 0.01);
    }

    @Test
    public void finalScoreTest2() {
        assertEquals(athlete3.athleteResult.finalScore(), athlete3.athleteResult.mostAthletes(), 0.01);
    }

    @Test
    public void betterSkiierTest1() {
        assertTrue(athlete1.betterSkiier(athlete2));
    }

    @Test
    public void betterShooterTest1() {
        assertTrue(athlete2.betterShooter(athlete1));
    }

    @Test
    public void hasBeatenTest1() {
        assertTrue(athlete1.hasBeaten(athlete2));
    }

    @Test
    public void hasBeatenTest2() {
        assertTrue(athlete2.hasBeaten(athlete1));
    }

    @Test
    public void bestRoundByTypeTest() {
        LinkedList<ShootingRound> roundz = new LinkedList<ShootingRound>();

        ShootingRound athlete1Round1 = new ShootingRound(1,false);
        ShootingRound athlete1Round2 = new ShootingRound(2,false);
        ShootingRound athlete1Round3 = new ShootingRound(5,false);
        ShootingRound athlete1Round4 = new ShootingRound(5, false);

        roundz.add(athlete1Round1);
        roundz.add(athlete1Round2);
        roundz.add(athlete1Round3);
        roundz.add(athlete1Round4);

        ShootingResult result = new ShootingResult(roundz);

      assertEquals(result.bestRoundByType(false),athlete1Round3);

    }

}
