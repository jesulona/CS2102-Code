import java.util.LinkedList;

public class MassStartResult extends Result implements IEvent {
    int startPosition;

    public MassStartResult(int startPostion, int finalPosition, double lap1Time, double lap2Time,
                           double lap3Time, double lap4Time, int penaltiesEarned) {
        super(finalPosition, lap1Time, lap2Time, lap3Time, lap4Time, penaltiesEarned);
        this.startPosition = startPostion;
    }
}
