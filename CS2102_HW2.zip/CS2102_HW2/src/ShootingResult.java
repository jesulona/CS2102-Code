import java.util.LinkedList;

public class ShootingResult implements IEvent {
    LinkedList<ShootingRound> listOfShootingRound;

    public ShootingResult(LinkedList<ShootingRound> listOfShootingRound) {
        this.listOfShootingRound = listOfShootingRound;
    }

    // pointsEarned() calculates the points earned by
    // summming the number of tarrgets hit
    public double pointsEarned() {
        double totalPoints = 0;

        for (ShootingRound round : this.listOfShootingRound) {
            round.roundHits += totalPoints;
        }
        return totalPoints;
    }

    // getPenalties() calculates the penalites following the
    // method described in the HW.
    public double getPenalties() {
        return (60 * ((5 * 4) - pointsEarned()));
        // (5 chances * 4 rounds) = 20 possible points => 20 - pointsEarned() = points missed
        // *60 per chance missed
    }

    //Write a method called bestRoundByType in the ShootingResult class to return the best
    // round in the list. The method should take a boolean as a parameter to indicate if we
    // want the best prone (false) or the best standing (true) round. If there is a tie between
    // the top two rounds, just return one of the rounds. If there are no rounds of the specified
    // type, return null.

    public ShootingRound bestRoundByType(boolean TF) {
        ShootingRound bestRound =  new ShootingRound(0, true);

        for (ShootingRound round : this.listOfShootingRound) {
            if ((round.roundHits > bestRound.roundHits) && round.standing == TF) {
                bestRound = round;
            }
            if (bestRound.roundHits == 0) {
                return null;
            }
        }
        return bestRound;
    }


}
